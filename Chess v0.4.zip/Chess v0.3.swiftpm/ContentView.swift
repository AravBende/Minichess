import SwiftUI

struct ContentView: View {
    @State private var hasOffset = false
    @GestureState var dragOffset = CGSize.zero 
    @State var position = CGSize.zero
    @State var position1 = CGSize.zero
    @State private var hasOffset1 = false
    @GestureState var dragOffset1 = CGSize.zero 
    @State var position2 = CGSize.zero
    @State private var hasOffset2 = false
    @GestureState var dragOffset2 = CGSize.zero 
    @State var position3 = CGSize.zero
    @State private var hasOffset3 = false
    @GestureState var dragOffset3 = CGSize.zero
    @State private var hasOffset4 = false
    @GestureState var dragOffset4 = CGSize.zero 
    @State var position4 = CGSize.zero
    @State var position5 = CGSize.zero
    @State private var hasOffset5 = false
    @GestureState var dragOffset5 = CGSize.zero 
    @State var position6 = CGSize.zero
    @State private var hasOffset6 = false
    @GestureState var dragOffset6 = CGSize.zero 
    @State var position7 = CGSize.zero
    @State private var hasOffset7 = false
    @GestureState var dragOffset7 = CGSize.zero
    @State private var ahasOffset = false
    @GestureState var adragOffset = CGSize.zero 
    @State var aposition = CGSize.zero
    @State var aposition1 = CGSize.zero
    @State private var ahasOffset1 = false
    @GestureState var adragOffset1 = CGSize.zero 
    @State var aposition2 = CGSize.zero
    @State private var ahasOffset2 = false
    @GestureState var adragOffset2 = CGSize.zero 
    @State var aposition3 = CGSize.zero
    @State private var ahasOffset3 = false
    @GestureState var adragOffset3 = CGSize.zero
    @State private var ahasOffset4 = false
    @GestureState var adragOffset4 = CGSize.zero 
    @State var aposition4 = CGSize.zero
    @State var aposition5 = CGSize.zero
    @State private var ahasOffset5 = false
    @GestureState var adragOffset5 = CGSize.zero 
    @State var aposition6 = CGSize.zero
    @State private var ahasOffset6 = false
    @GestureState var adragOffset6 = CGSize.zero 
    @State var aposition7 = CGSize.zero
    @State private var ahasOffset7 = false
    @GestureState var adragOffset7 = CGSize.zero
    
    
    
    var body: some View {
        ZStack {
            Image("chess_board")
                .resizable()
                .offset(x: 0,y: 0)
                .frame(width:400 ,height: 500)
                .padding()
            
            Image("wpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -150,y: 100)
                .offset(x: position.width + dragOffset.width, y: position.height + dragOffset.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position.height += value.translation.height
                            self.position.width += value.translation.width
                            print("height",position.height)
                            print("width",position.width)
                        })
                )
            Image("wpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -52,y: 100)
                .offset(x: position1.width + dragOffset1.width, y: position1.height + dragOffset1.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset1, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position1.height += value.translation.height
                            self.position1.width += value.translation.width
                            print("height",position1.height)
                            print("width",position1.width)
                        })
                )
            
            Image("wpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 52,y: 100)
                .offset(x: position2.width + dragOffset2.width, y: position2.height + dragOffset2.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset2, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position2.height += value.translation.height
                            self.position2.width += value.translation.width
                            print("height",position2.height)
                            print("width",position2.width)
                        })
                )
            
            Image("wpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 152,y: 100)
                .offset(x: position3.width + dragOffset3.width, y: position3.height + dragOffset3.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset3, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position3.height += value.translation.height
                            self.position3.width += value.translation.width
                            print("height",position3.height)
                            print("width",position3.width)
                        })
                )
            Image("wrook")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -150,y: 200)
                .offset(x: position4.width + dragOffset4.width, y: position4.height + dragOffset4.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset4, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position4.height += value.translation.height
                            self.position4.width += value.translation.width
                            print("height",position4.height)
                            print("width",position4.width)
                        })
                )
            Image("wqueen")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -52,y: 200)
                .offset(x: position5.width + dragOffset5.width, y: position5.height + dragOffset5.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset5, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position5.height += value.translation.height
                            self.position5.width += value.translation.width
                            print("height",position5.height)
                            print("width",position5.width)
                        })
                )
            
            Image("wking")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 52,y: 200)
                .offset(x: position6.width + dragOffset6.width, y: position6.height + dragOffset6.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset6, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position6.height += value.translation.height
                            self.position6.width += value.translation.width
                            print("height",position6.height)
                            print("width",position6.width)
                        })
                )
            
            Image("wrook")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 152,y: 200)
                .offset(x: position7.width + dragOffset7.width, y: position7.height + dragOffset7.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset7, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.position7.height += value.translation.height
                            self.position7.width += value.translation.width
                            print("height",position7.height)
                            print("width",position7.width)
                        })
                )
            Image("bpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -150,y: 100)
                .offset(x: aposition.width + adragOffset.width, y: aposition.height + adragOffset.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition.height += value.translation.height
                            self.aposition.width += value.translation.width
                            print("height",aposition.height)
                            print("width",aposition.width)
                        })
                )
            Image("bpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -52,y: 100)
                .offset(x: aposition1.width + adragOffset1.width, y: aposition1.height + adragOffset1.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset1, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition1.height += value.translation.height
                            self.aposition1.width += value.translation.width
                            print("height",aposition1.height)
                            print("width",aposition1.width)
                        })
                )
            
            Image("bpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 52,y: 100)
                .offset(x: aposition2.width + adragOffset2.width, y: aposition2.height + adragOffset2.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset2, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition2.height += value.translation.height
                            self.aposition2.width += value.translation.width
                            print("height",aposition2.height)
                            print("width",aposition2.width)
                        })
                )
            
            Image("bpawn")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 152,y: 100)
                .offset(x: aposition3.width + adragOffset3.width, y: aposition3.height + adragOffset3.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset3, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition3.height += value.translation.height
                            self.aposition3.width += value.translation.width
                            print("height",aposition3.height)
                            print("width",aposition3.width)
                        })
                )
            Image("brook")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -150,y: 200)
                .offset(x: aposition4.width + adragOffset4.width, y: aposition4.height + adragOffset4.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset4, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition4.height += value.translation.height
                            self.aposition4.width += value.translation.width
                            print("height",aposition4.height)
                            print("width",aposition4.width)
                        })
                )
            Image("bqueen")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: -52,y: 200)
                .offset(x: aposition5.width + adragOffset5.width, y: aposition5.height + adragOffset5.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset5, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition5.height += value.translation.height
                            self.aposition5.width += value.translation.width
                            print("height",aposition5.height)
                            print("width",aposition5.width)
                        })
                )
            
            Image("bking")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 52,y: 200)
                .offset(x: aposition6.width + adragOffset6.width, y: aposition6.height + adragOffset6.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset6, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition6.height += value.translation.height
                            self.aposition6.width += value.translation.width
                            print("height",aposition6.height)
                            print("width",aposition6.width)
                        })
                )
            
            Image("brook")
                .resizable()
                .frame(width: 90,height: 90)
                .offset(x: 152,y: 200)
                .offset(x: aposition7.width + adragOffset7.width, y: aposition7.height + adragOffset7.height)
                .gesture(
                    DragGesture()
                        .updating($adragOffset7, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in
                            self.aposition7.height += value.translation.height
                            self.aposition7.width += value.translation.width
                            print("height",aposition7.height)
                            print("width",aposition7.width)
                        })
                )
            
        }
    }
}
